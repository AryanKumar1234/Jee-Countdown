package com.jee.countdown;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.Button;
import android.content.SharedPreferences;
import java.util.Calendar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ticking = false;
    private TextView title, sub, msg;
    private TextView[] nums;
    private final Random rnd = new Random();

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            bind();
            long now = System.currentTimeMillis();
            h.postDelayed(this, 1000 - (now % 1000) + 5);
        }
    };

    private final Runnable hideMsg = () -> msg.setText("");

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        title = findViewById(R.id.a_title);
        sub = findViewById(R.id.a_sub);
        msg = findViewById(R.id.a_msg);
        nums = new TextView[]{
                findViewById(R.id.a_y), findViewById(R.id.a_d), findViewById(R.id.a_h),
                findViewById(R.id.a_m), findViewById(R.id.a_s)};

        Button mains = findViewById(R.id.a_mains);
        Button advanced = findViewById(R.id.a_advanced);
        mains.setOnClickListener(v -> {
            Updater.selectMains(this);
            updateExamButtons(mains, advanced);
            bind();
        });
        advanced.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.add(Calendar.MONTH, 6);
            SharedPreferences sp = getSharedPreferences("jee", MODE_PRIVATE);
            long saved = sp.getLong("advanced_picker_epoch", c.getTimeInMillis());
            c.setTimeInMillis(saved);
            new DatePickerDialog(this, (view, year, month, day) -> {
                Calendar chosen = Calendar.getInstance();
                chosen.set(year, month, day, 9, 0, 0);
                chosen.set(Calendar.MILLISECOND, 0);
                sp.edit().putLong("advanced_picker_epoch", chosen.getTimeInMillis()).apply();
                Updater.selectAdvanced(this, chosen.getTimeInMillis());
                updateExamButtons(mains, advanced);
                bind();
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
        });
        updateExamButtons(mains, advanced);

        TextView plus = findViewById(R.id.a_plus);
        plus.setOnClickListener(v -> {
            plus.animate().rotationBy(90f).setDuration(200).start();
            msg.setText("padhle B**K");
            Toast.makeText(this, "padhle B**K", Toast.LENGTH_SHORT).show();
            h.removeCallbacks(hideMsg);
            h.postDelayed(hideMsg, 3000);
            for (int i = 0; i < 6; i++) h.postDelayed(() -> burst(plus), i * 120L);
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Updater.schedule(this);
        Updater.startLive(this);   // keeps widget seconds running too
        Updater.pokeForce(this);   // fetch the latest date and news
        ticking = true;
        h.post(tick);
    }

    @Override
    protected void onPause() {
        ticking = false;
        h.removeCallbacks(tick);
        super.onPause();
    }

    /** One emoji floats up from the + button, like the Facebook like animation. */
    private void burst(View from) {
        final FrameLayout fx = findViewById(R.id.a_fx);
        final TextView e = new TextView(this);
        e.setText("\uD83D\uDD95");
        e.setTextSize(36);
        int[] a = new int[2], b = new int[2];
        from.getLocationOnScreen(a);
        fx.getLocationOnScreen(b);
        float d = getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = a[0] - b[0] + from.getWidth() / 2 - (int) (24 * d);
        lp.topMargin = a[1] - b[1] - (int) (10 * d);
        fx.addView(e, lp);
        e.setScaleX(0.2f);
        e.setScaleY(0.2f);
        e.animate()
                .translationX((rnd.nextFloat() - 0.5f) * 140 * d)
                .translationY(-(220 + rnd.nextFloat() * 160) * d)
                .scaleX(1.5f).scaleY(1.5f)
                .alpha(0f)
                .setDuration(1300)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(() -> fx.removeView(e))
                .start();
    }

    private void updateExamButtons(Button mains, Button advanced) {
        boolean isAdvanced = Updater.isAdvanced(this);
        mains.setAlpha(isAdvanced ? 0.55f : 1f);
        advanced.setAlpha(isAdvanced ? 1f : 0.55f);
    }

    private void bind() {
        long[] v = Updater.parts(this);
        boolean leadingZero = true;
        for (int i = 0; i < 5; i++) {
            if (v[i] != 0) leadingZero = false;
            nums[i].setText(v[i] < 10 ? "0" + v[i] : String.valueOf(v[i]));
            nums[i].setTextColor(leadingZero && i < 4 ? 0xFFE10600 : 0xFFFFFFFF);
        }
        title.setText(Updater.title(this));
        sub.setText(Updater.subtitle(this));
    }
}
