package com.jee.countdown;

import android.animation.ArgbEvaluator;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.util.Xml;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

final class Updater {
    static final String ACTION_TICK = "com.jee.countdown.TICK";
    static final String ACTION_FORCE = "com.jee.countdown.FORCE";
    static final String ACTION_PLUS = "com.jee.countdown.PLUS";

    // Built-in fallback, used until the date has been fetched from the internet.
    private static final long FALLBACK_EPOCH =
            ZonedDateTime.of(2027, 1, 20, 0, 0, 0, 0, ZoneId.of("Asia/Kolkata")).toEpochSecond();
    private static final String FALLBACK_TITLE = "JEE MAINS 2027";

    private static final String NEWS_URL =
            "https://news.google.com/rss/search?q=JEE+Main+OR+JEE+Advanced+OR+JoSAA"
                    + "+OR+IIT+JEE+OR+NTA+JEE+when:7d&hl=en-IN&gl=IN&ceid=IN:en";

    private static final long DATE_OK_MS = 6L * 3600_000L;
    private static final long DATE_RETRY_MS = 15L * 60_000L;
    private static final long NEWS_OK_MS = 30L * 60_000L;
    private static final long NEWS_RETRY_MS = 10L * 60_000L;

    private static final double[] STOP_DAYS = {100, 80, 60, 40, 20, 10, 5, 0};
    private static final int[] STOP_COLORS = {
            0xFF1B8A5A, // 100+ days  green
            0xFF7CB342, // 80         lime
            0xFFF9A825, // 60         amber
            0xFFFB8C00, // 40         orange
            0xFFF4511E, // 20         deep orange
            0xFFE53935, // 10         red
            0xFFC62828, // 5          crimson
            0xFF8E0000  // 0          dark red
    };

    // Every phase has its own pool. One quote is picked per calendar day, so the
    // line changes at midnight (and never repeats two days in a row).
    private static final String[] FAR_QUOTES = {            // more than 100 days
            "Plenty of time. Build the habit.",
            "Small daily wins add up to big ranks.",
            "Start the chapter you've been avoiding.",
            "Consistency beats intensity. Show up today.",
            "Fix one weak topic this week.",
            "Today's practice is tomorrow's confidence.",
            "Make a plan, then follow it.",
            "Strong basics make hard problems easy.",
            "One solved problem a day beats none.",
            "Sleep on time. Memory is built at night.",
            "Don't count the days. Make them count.",
            "Build the base. Speed comes later."
    };

    private static final String[] MID_QUOTES = {            // 60 to 100 days
            "Stay consistent. Finish the syllabus.",
            "Syllabus first, perfection later.",
            "Every chapter closed is one less worry.",
            "Solve, don't just read.",
            "Track your weak topics and attack them.",
            "Take a full test every week.",
            "Notes today save panic tomorrow.",
            "Keep your streak alive. Study today.",
            "Revise what you learned last week.",
            "Progress over perfection. Keep moving.",
            "Mistakes now mean fewer mistakes in the exam.",
            "Discipline works even on tired days."
    };

    private static final String[] NEAR_QUOTES = {           // 20 to 60 days
            "Revision mode. Mock tests daily.",
            "Analyse every mock. Mistakes are the lesson.",
            "Revise formulas every single day.",
            "Practice under exam timing.",
            "Attempt strategy matters. Practice it.",
            "Easy marks first, hard ones later.",
            "Stop learning new things. Polish what you know.",
            "Previous year papers are your best friend.",
            "Silly mistakes cost the most. Fix them.",
            "Short notes, quick revision, repeat.",
            "Stay fit. Walk, stretch, hydrate.",
            "Every mock is a rehearsal. Treat it so."
    };

    private static final String[] FINAL_QUOTES = {          // 7 to 20 days
            "Final stretch. Stay calm, stay sharp.",
            "Revise, don't rush. You know more than you think.",
            "Accuracy first, speed second.",
            "Keep your sleep schedule steady.",
            "Revise formula sheets, not new topics.",
            "Don't compare. Run your own race.",
            "Short breaks keep the mind fresh.",
            "Ignore panic talk. Stick to your plan.",
            "Eat well, sleep well, revise well.",
            "The finish line is close. Keep going.",
            "Rest is part of the plan.",
            "Believe in your hard work."
    };

    private static final String[] CALM_QUOTES = {          // last 7 days
            "Breathe. You've already done the work.",
            "Calm mind, sharp mind.",
            "One question at a time. That's all.",
            "Sleep well. Rest is part of revision.",
            "You are more prepared than you feel.",
            "Trust your preparation.",
            "Stay relaxed. Marks follow focus.",
            "Do your best, then let it go.",
            "Take a walk. Drink water. Smile.",
            "This exam is one step, not your whole story.",
            "Slow is smooth, smooth is fast.",
            "Be proud of how far you've come.",
            "Nervous means you care. Use it.",
            "Your hard work is done. Stay steady."
    };

    private static final String[] LAST_DAY_QUOTES = {      // final 24 hours
            "Light revision, early sleep. You've got this!",
            "Tomorrow is just another paper. Stay calm.",
            "Check your admit card. Then rest.",
            "Trust yourself. You've earned this.",
            "Eat light, sleep early, smile.",
            "No new topics today. Just relax.",
            "You're ready. Go show it.",
            "One deep breath. You've got this."
    };

    private static final int ADV_SALT = 5;

    private Updater() {}

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("jee", Context.MODE_PRIVATE);
    }

    // ---------------------------------------------------------------- scheduling

    private static PendingIntent tickPi(Context c) {
        Intent i = new Intent(c, TickReceiver.class).setAction(ACTION_TICK);
        return PendingIntent.getBroadcast(c, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent forcePi(Context c) {
        Intent i = new Intent(c, TickReceiver.class).setAction(ACTION_FORCE);
        return PendingIntent.getBroadcast(c, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void schedule(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        long now = System.currentTimeMillis();
        long next = now - (now % 60000L) + 60000L;
        am.setAndAllowWhileIdle(AlarmManager.RTC, next, tickPi(c));
    }

    static void cancelIfUnused(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int n = m.getAppWidgetIds(new ComponentName(c, JeeWidget.class)).length
                + m.getAppWidgetIds(new ComponentName(c, MovieWidget.class)).length
                + m.getAppWidgetIds(new ComponentName(c, AdvancedWidget.class)).length
                + m.getAppWidgetIds(new ComponentName(c, NewsWidget.class)).length;
        if (n == 0) {
            ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(tickPi(c));
            c.stopService(new Intent(c, LiveService.class));
        }
    }

    /** Starts the per-second updater. Android may refuse from the background; that is fine. */
    static void startLive(Context c) {
        if (LiveService.running) return;
        try {
            c.startForegroundService(new Intent(c, LiveService.class));
        } catch (Exception ignored) {
        }
    }

    /** Ask TickReceiver (which can use a background thread) to refresh now. */
    static void poke(Context c) {
        c.sendBroadcast(new Intent(c, TickReceiver.class).setAction(ACTION_TICK));
    }

    // ---------------------------------------------------------------- refresh

    static void refresh(Context c, boolean force) {
        render(c);
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        boolean changed = false;
        if (force || now >= sp.getLong("date_next", 0)) changed |= fetchDate(c);
        if (force || now >= sp.getLong("news_next", 0)) changed |= fetchNews(c);
        if (changed) render(c);
    }

    static void render(Context c) {
        renderCountdowns(c);
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        SharedPreferences sp = prefs(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, NewsWidget.class)))
            m.updateAppWidget(id, news(c, sp));
    }

    /** Full redraw of the countdown widgets (layout + click handlers). Used for minute ticks and changes. */
    static void renderCountdowns(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        SharedPreferences sp = prefs(c);
        for (int id : m.getAppWidgetIds(new ComponentName(c, JeeWidget.class)))
            m.updateAppWidget(id, countdownFor(c, sp, false));
        for (int id : m.getAppWidgetIds(new ComponentName(c, AdvancedWidget.class)))
            m.updateAppWidget(id, countdownFor(c, sp, true));
        for (int id : m.getAppWidgetIds(new ComponentName(c, MovieWidget.class)))
            m.updateAppWidget(id, movie(c, sp, true));
    }

    /**
     * Cheap per-second update: only the text that changed is sent, using a partial update,
     * so the launcher does not re-inflate the layout or rebind click handlers every second.
     */
    static void tickCountdowns(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        SharedPreferences sp = prefs(c);
        int[] jee = m.getAppWidgetIds(new ComponentName(c, JeeWidget.class));
        int[] mov = m.getAppWidgetIds(new ComponentName(c, MovieWidget.class));
        int[] adv = m.getAppWidgetIds(new ComponentName(c, AdvancedWidget.class));
        if (jee.length == 0 && mov.length == 0 && adv.length == 0) return;

        long secs = remaining(sp);
        long minuteKey = System.currentTimeMillis() / 60000L;
        // a new minute (or a flash ending) needs the colour/subtitle too: do a full redraw
        if (minuteKey != lastMinuteKey || (lastFlashing && System.currentTimeMillis() >= sp.getLong("flash_until", 0))) {
            lastMinuteKey = minuteKey;
            lastFlashing = false;
            renderCountdowns(c);
            return;
        }
        // Mains and Advanced share the exact same tick: only the digits change every second.
        // Title, colour, quote and the "padhle bhai" flash come from the full redraw
        // (countdownFor), so a tick must never overwrite them.
        if (jee.length > 0) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_jee);
            rv.setTextViewText(R.id.num, numText(Math.max(0L, mainRemaining(sp))));
            m.partiallyUpdateAppWidget(jee, rv);
        }
        if (adv.length > 0) {
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_advanced);
            rv.setTextViewText(R.id.num, numText(Math.max(0L, advancedRemaining(sp))));
            m.partiallyUpdateAppWidget(adv, rv);
        }
        if (mov.length > 0) {
            long safe = Math.max(0L, secs);
            long days = safe / 86400L;
            RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_movie);
            rv.setTextViewText(R.id.m_y, two(days / 365L));
            rv.setTextViewText(R.id.m_d, two(days % 365L));
            rv.setTextViewText(R.id.m_h, two((safe % 86400L) / 3600L));
            rv.setTextViewText(R.id.m_m, two((safe % 3600L) / 60L));
            rv.setTextViewText(R.id.m_s, two(safe % 60L));
            m.partiallyUpdateAppWidget(mov, rv);
        }
    }

    private static long lastMinuteKey = Long.MIN_VALUE;
    private static boolean lastFlashing = false;

    private static String numText(long secs) {
        if (secs < 0) secs = 0;
        long totalDays = secs / 86400L;
        return two(totalDays / 365L) + ":" + two(totalDays % 365L) + ":" + two((secs % 86400L) / 3600L)
                + ":" + two((secs % 3600L) / 60L) + ":" + two(secs % 60L);
    }

    // ---------------------------------------------------------------- network

    private static String httpGet(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(5000);
        con.setReadTimeout(5000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) JEECountdown");
        try {
            if (con.getResponseCode() != 200) throw new IOException("HTTP " + con.getResponseCode());
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    total += n;
                    if (total > 2_000_000) break;
                }
                return out.toString("UTF-8");
            }
        } finally {
            con.disconnect();
        }
    }

    private static boolean fetchDate(Context c) {
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        try {
            JSONObject o = new JSONObject(httpGet(c.getString(R.string.config_url)));
            long epoch = OffsetDateTime.parse(o.getString("date")).toEpochSecond();
            float preview = o.has("preview_days") ? (float) o.getDouble("preview_days") : -1f;
            sp.edit().putLong("exam_epoch", epoch)
                    .putFloat("preview_days", preview)
                    .putString("exam_name", o.optString("name", FALLBACK_TITLE))
                    .putLong("date_next", now + DATE_OK_MS).apply();
            return true;
        } catch (Exception e) {
            sp.edit().putLong("date_next", now + DATE_RETRY_MS).apply();
            return false;
        }
    }

    private static boolean fetchNews(Context c) {
        SharedPreferences sp = prefs(c);
        long now = System.currentTimeMillis();
        try {
            String xml = httpGet(NEWS_URL);
            XmlPullParser p = Xml.newPullParser();
            p.setInput(new StringReader(xml));
            JSONArray arr = new JSONArray();
            boolean inItem = false;
            String title = null, link = null, date = null;
            int ev = p.getEventType();
            while (ev != XmlPullParser.END_DOCUMENT && arr.length() < 6) {
                if (ev == XmlPullParser.START_TAG) {
                    String n = p.getName();
                    if ("item".equals(n)) {
                        inItem = true;
                        title = null; link = null; date = null;
                    } else if (inItem) {
                        if ("title".equals(n)) title = p.nextText();
                        else if ("link".equals(n)) link = p.nextText();
                        else if ("pubDate".equals(n)) date = p.nextText();
                    }
                } else if (ev == XmlPullParser.END_TAG && "item".equals(p.getName())) {
                    inItem = false;
                    if (title != null && link != null) {
                        String src = "";
                        int i = title.lastIndexOf(" - ");
                        if (i > 0) {
                            src = title.substring(i + 3);
                            title = title.substring(0, i);
                        }
                        long t = now;
                        try {
                            t = ZonedDateTime.parse(date, DateTimeFormatter.RFC_1123_DATE_TIME)
                                    .toInstant().toEpochMilli();
                        } catch (Exception ignored) {}
                        JSONObject o = new JSONObject();
                        o.put("h", title.trim());
                        o.put("s", src);
                        o.put("l", link.trim());
                        o.put("t", t);
                        arr.put(o);
                    }
                }
                ev = p.next();
            }
            if (arr.length() == 0) throw new IOException("no items");
            sp.edit().putString("news", arr.toString()).putLong("news_at", now)
                    .putLong("news_next", now + NEWS_OK_MS).apply();
            return true;
        } catch (Exception e) {
            sp.edit().putLong("news_next", now + NEWS_RETRY_MS).apply();
            return false;
        }
    }

    // ---------------------------------------------------------------- countdown view

    private static PendingIntent plusPi(Context c) {
        Intent i = new Intent(c, TickReceiver.class).setAction(ACTION_PLUS);
        return PendingIntent.getBroadcast(c, 3, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Show "padhle bhai" in the widget subtitle for 3 seconds. */
    static void flash(Context c) {
        prefs(c).edit().putLong("flash_until", System.currentTimeMillis() + 3000).apply();
        lastFlashing = true;
        renderCountdowns(c);
    }

    private static PendingIntent openAppPi(Context c) {
        Intent i = new Intent(c, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(c, 2, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Refresh date and news right now (used when the app is opened). */
    static void pokeForce(Context c) {
        c.sendBroadcast(new Intent(c, TickReceiver.class).setAction(ACTION_FORCE));
    }

    /** {years, days, hours, minutes, seconds} left, for the app screen. */
    static void selectMains(Context c) {
        prefs(c).edit().remove("selected_exam").remove("selected_epoch").apply();
        render(c);
    }

    static long defaultAdvancedEpochMillis() {
        return ZonedDateTime.of(2027, 5, 23, 9, 0, 0, 0,
                ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli();
    }

    static void selectAdvancedDefault(Context c) {
        long epoch = defaultAdvancedEpochMillis();
        prefs(c).edit().putString("selected_exam", "JEE ADVANCED 2027")
                .putLong("selected_epoch", epoch / 1000L)
                .putLong("advanced_picker_epoch", epoch).apply();
        lastMinuteKey = Long.MIN_VALUE;
        render(c);
    }

    static void selectAdvanced(Context c, long epochMillis) {
        prefs(c).edit().putString("selected_exam", "JEE ADVANCED 2027")
                .putLong("selected_epoch", epochMillis / 1000L).apply();
        lastMinuteKey = Long.MIN_VALUE;
        render(c);
    }

    static boolean isAdvanced(Context c) {
        return "JEE ADVANCED 2027".equals(prefs(c).getString("selected_exam", ""));
    }

    static long[] parts(Context c) {
        long secs = remaining(prefs(c));
        if (secs < 0) secs = 0;
        long totalDays = secs / 86400L;
        return new long[]{totalDays / 365L, totalDays % 365L,
                (secs % 86400L) / 3600L, (secs % 3600L) / 60L, secs % 60L};
    }

    static String title(Context c) {
        SharedPreferences sp = prefs(c);
        String name = sp.getString("selected_exam", sp.getString("exam_name", FALLBACK_TITLE));
        if (sp.getFloat("preview_days", -1f) >= 0) name += " (PREVIEW)";
        return name;
    }

    static String subtitle(Context c) {
        long secs = remaining(prefs(c));
        if (secs <= 0) return "Exam time. All the best!";
        return message(secs / 86400.0, isAdvanced(c) ? ADV_SALT : 0);
    }

    private static long remaining(SharedPreferences sp) {
        long exam = sp.getLong("selected_epoch", sp.getLong("exam_epoch", FALLBACK_EPOCH));
        long secs = exam - System.currentTimeMillis() / 1000L;
        float preview = sp.getFloat("preview_days", -1f);
        if (preview >= 0) secs = (long) (preview * 86400L); // test mode from exam.json
        return secs;
    }

    private static long mainRemaining(SharedPreferences sp) {
        return sp.getLong("exam_epoch", FALLBACK_EPOCH) - System.currentTimeMillis() / 1000L;
    }

    private static long advancedRemaining(SharedPreferences sp) {
        long epochMillis = sp.getLong("advanced_picker_epoch", defaultAdvancedEpochMillis());
        return epochMillis / 1000L - System.currentTimeMillis() / 1000L;
    }

    private static RemoteViews countdownFor(Context c, SharedPreferences sp, boolean advanced) {
        int layout = advanced ? R.layout.widget_advanced : R.layout.widget_jee;
        RemoteViews rv = new RemoteViews(c.getPackageName(), layout);
        long secs;
        String name;
        if (advanced) {
            secs = advancedRemaining(sp);
            name = "JEE ADVANCED 2027";
        } else {
            secs = mainRemaining(sp);
            name = sp.getString("exam_name", FALLBACK_TITLE);
        }
        boolean over = secs <= 0;
        if (over) secs = 0;
        rv.setTextViewText(R.id.title, name);
        rv.setTextViewText(R.id.num, numText(secs));
        boolean flashing = System.currentTimeMillis() < sp.getLong("flash_until", 0);
        rv.setTextViewText(R.id.subtitle, flashing ? "padhle bhai"
                : over ? "Exam time. All the best!" : message(secs / 86400.0, advanced ? ADV_SALT : 0));
        rv.setInt(R.id.bg, "setColorFilter", colorFor(secs / 86400.0));
        rv.setOnClickPendingIntent(R.id.root, openAppPi(c));
        return rv;
    }

    /** Movie-style stacked countdown on a transparent background. */
    private static RemoteViews movie(Context c, SharedPreferences sp, boolean full) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_movie);

        long secs = remaining(sp);
        if (secs < 0) secs = 0;

        long totalDays = secs / 86400L;
        long[] v = {
                totalDays / 365L,
                totalDays % 365L,
                (secs % 86400L) / 3600L,
                (secs % 3600L) / 60L,
                secs % 60L
        };
        int[] ids = {R.id.m_y, R.id.m_d, R.id.m_h, R.id.m_m, R.id.m_s};

        boolean leadingZero = true;
        for (int i = 0; i < 5; i++) {
            if (v[i] != 0) leadingZero = false;
            rv.setTextViewText(ids[i], two(v[i]));
            // like the movie: leading zero units are red, the rest white
            rv.setTextColor(ids[i], leadingZero && i < 4 ? 0xFFE10600 : 0xFFFFFFFF);
        }
        rv.setOnClickPendingIntent(R.id.root_movie, openAppPi(c));
        return rv;
    }

    /** One quote per calendar day from the pool for the current phase. */
    private static String pick(String[] pool, int salt) {
        long day = java.time.LocalDate.now().toEpochDay();
        return pool[(int) Math.floorMod(day + salt, (long) pool.length)];
    }

    /** salt offsets the daily pick so Mains and Advanced don't show the same line in the same phase. */
    private static String message(double d, int salt) {
        if (d > 100) return pick(FAR_QUOTES, salt);
        if (d > 60) return pick(MID_QUOTES, salt);
        if (d > 20) return pick(NEAR_QUOTES, salt);
        if (d > 7) return pick(FINAL_QUOTES, salt);
        if (d <= 1) return pick(LAST_DAY_QUOTES, salt);
        return pick(CALM_QUOTES, salt);
    }

    private static String two(long v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static int colorFor(double days) {
        if (days >= STOP_DAYS[0]) return STOP_COLORS[0];
        ArgbEvaluator ev = new ArgbEvaluator();
        for (int i = 0; i < STOP_DAYS.length - 1; i++) {
            if (days >= STOP_DAYS[i + 1]) {
                float t = (float) ((STOP_DAYS[i] - days) / (STOP_DAYS[i] - STOP_DAYS[i + 1]));
                return (int) ev.evaluate(t, STOP_COLORS[i], STOP_COLORS[i + 1]);
            }
        }
        return STOP_COLORS[STOP_COLORS.length - 1];
    }

    // ---------------------------------------------------------------- news view

    private static final int[] ROW = {R.id.r0, R.id.r1, R.id.r2, R.id.r3};
    private static final int[] ROW_T = {R.id.r0_t, R.id.r1_t, R.id.r2_t, R.id.r3_t};
    private static final int[] ROW_M = {R.id.r0_m, R.id.r1_m, R.id.r2_m, R.id.r3_m};

    private static RemoteViews news(Context c, SharedPreferences sp) {
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_news);
        rv.setOnClickPendingIntent(R.id.news_header, forcePi(c));

        long at = sp.getLong("news_at", 0);
        rv.setTextViewText(R.id.news_updated, at == 0 ? "" : "Updated " +
                DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
                        .format(Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault())));

        JSONArray arr;
        try {
            arr = new JSONArray(sp.getString("news", "[]"));
        } catch (JSONException e) {
            arr = new JSONArray();
        }

        for (int i = 0; i < 4; i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) {
                rv.setViewVisibility(ROW[i], View.VISIBLE);
                rv.setTextViewText(ROW_T[i], o.optString("h"));
                String meta = o.optString("s");
                String ago = ago(o.optLong("t"));
                rv.setTextViewText(ROW_M[i], meta.isEmpty() ? ago : meta + " · " + ago);
                Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(o.optString("l")))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                rv.setOnClickPendingIntent(ROW[i], PendingIntent.getActivity(c, 100 + i, it,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
            } else if (i == 0) {
                rv.setViewVisibility(ROW[0], View.VISIBLE);
                rv.setTextViewText(ROW_T[0], "Fetching latest JEE updates. Tap the header to refresh.");
                rv.setTextViewText(ROW_M[0], "Needs internet");
            } else {
                rv.setViewVisibility(ROW[i], View.GONE);
            }
        }
        return rv;
    }

    private static String ago(long t) {
        long m = Math.max(0, (System.currentTimeMillis() - t) / 60000L);
        if (m < 60) return m + "m ago";
        if (m < 1440) return (m / 60) + "h ago";
        return (m / 1440) + "d ago";
    }
}
