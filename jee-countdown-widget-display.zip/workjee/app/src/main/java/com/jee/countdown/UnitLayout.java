package com.jee.countdown;

import android.content.SharedPreferences;

/**
 * Which time units the widgets show, and in what order.
 * Units are indexed biggest to smallest: 0=years 1=days 2=hours 3=minutes 4=seconds.
 * Stored as e.g. "y1,d1,h1,m1,s1" (letter = unit, 1/0 = shown/hidden); the list order is the display order.
 */
final class UnitLayout {
    static final String PREF = "unit_layout";
    static final String DEFAULT = "y1,d1,h1,m1,s1";

    static final String KEYS = "ydhms";
    static final long[] SECS = {365L * 86400L, 86400L, 3600L, 60L, 1L};
    static final String[] SHORT = {"YY", "DD", "HH", "MM", "SS"};
    static final String[] TILE = {"YEARS", "DAYS", "HOURS", "MINS", "SECS"};
    static final String[] ROW = {"YRS", "DAY", "HRS", "MIN", "SEC"};

    /** unit index shown at each position, left to right */
    final int[] order = new int[5];
    /** shown/hidden, indexed by unit index */
    final boolean[] on = new boolean[5];

    static UnitLayout load(SharedPreferences sp) {
        return parse(sp.getString(PREF, DEFAULT));
    }

    static UnitLayout parse(String s) {
        UnitLayout u = new UnitLayout();
        boolean[] seen = new boolean[5];
        int n = 0;
        if (s != null) {
            for (String part : s.split(",")) {
                part = part.trim();
                if (part.length() != 2) continue;
                int idx = KEYS.indexOf(part.charAt(0));
                if (idx < 0 || seen[idx]) continue;
                seen[idx] = true;
                u.order[n++] = idx;
                u.on[idx] = part.charAt(1) == '1';
            }
        }
        for (int i = 0; i < 5; i++) {          // anything missing goes at the end, shown
            if (!seen[i]) {
                u.order[n++] = i;
                u.on[i] = true;
            }
        }
        if (u.visibleCount() == 0) {            // never allow an empty widget
            for (int i = 0; i < 5; i++) u.on[i] = true;
        }
        return u;
    }

    static UnitLayout defaults() {
        return parse(DEFAULT);
    }

    UnitLayout copy() {
        return parse(serialize());
    }

    String serialize() {
        StringBuilder sb = new StringBuilder();
        for (int pos = 0; pos < 5; pos++) {
            int unit = order[pos];
            if (pos > 0) sb.append(',');
            sb.append(KEYS.charAt(unit)).append(on[unit] ? '1' : '0');
        }
        return sb.toString();
    }

    int visibleCount() {
        int n = 0;
        for (int i = 0; i < 5; i++) if (on[i]) n++;
        return n;
    }

    /**
     * Value of every unit for this many seconds. A hidden unit is not lost: its time rolls
     * into the next smaller shown unit (hide YY and DD shows the full day count).
     */
    long[] values(long secs) {
        long[] v = new long[5];
        long rem = Math.max(0L, secs);
        for (int i = 0; i < 5; i++) {          // biggest to smallest, regardless of display order
            if (!on[i]) continue;
            v[i] = rem / SECS[i];
            rem %= SECS[i];
        }
        return v;
    }

    /** "00:57:09:44:23" style text in display order, shown units only. */
    String text(long secs) {
        long[] v = values(secs);
        StringBuilder sb = new StringBuilder();
        for (int pos = 0; pos < 5; pos++) {
            int unit = order[pos];
            if (!on[unit]) continue;
            if (sb.length() > 0) sb.append(':');
            sb.append(v[unit] < 10 ? "0" + v[unit] : String.valueOf(v[unit]));
        }
        return sb.toString();
    }
}
