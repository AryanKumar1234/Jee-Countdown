package com.jee.countdown;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A row of 5 tiles (YY DD HH MM SS). Drag a tile sideways to reorder, tap it to show or hide.
 * The other tiles slide out of the way while you drag. Built on plain framework views.
 */
public class TileBoard extends FrameLayout {
    interface Listener {
        void onChanged(UnitLayout layout);
    }

    private static final int PAD_DP = 8;      // room above/below so a lifted tile is not clipped
    private static final int GAP_DP = 8;
    private static final int TILE_H_DP = 88;

    private final TextView[] tiles = new TextView[5];   // indexed by unit index
    private UnitLayout state = UnitLayout.defaults();
    private Listener listener;
    private int accent = 0xFFE10600;
    private int tileW, tileH, gap, pad;
    private final int slop;

    public TileBoard(Context c) { this(c, null); }

    public TileBoard(Context c, AttributeSet a) {
        super(c, a);
        float d = c.getResources().getDisplayMetrics().density;
        gap = (int) (GAP_DP * d);
        pad = (int) (PAD_DP * d);
        tileH = (int) (TILE_H_DP * d);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        setClipChildren(false);
        setClipToPadding(false);
        for (int unit = 0; unit < 5; unit++) {
            TextView t = new TextView(c);
            t.setGravity(Gravity.CENTER);
            t.setIncludeFontPadding(false);
            t.setTextSize(22);
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
            SpannableString s = new SpannableString(UnitLayout.SHORT[unit] + "\n" + UnitLayout.TILE[unit]);
            s.setSpan(new RelativeSizeSpan(0.42f), 3, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            t.setText(s);
            tiles[unit] = t;
            addView(t, new LayoutParams(1, 1));
            attachTouch(t, unit);
        }
        restyleAll();
    }

    void setListener(Listener l) { listener = l; }

    void setAccent(int color) {
        accent = color;
        restyleAll();
    }

    void setState(UnitLayout u) {
        state = u.copy();
        restyleAll();
        positionAll(false, -1);
    }

    /** Back to YY DD HH MM SS, all shown. */
    void reset() {
        state = UnitLayout.defaults();
        restyleAll();
        positionAll(true, -1);
        notifyChanged();
    }

    // ------------------------------------------------------------------ layout

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        tileW = Math.max(1, (w - getPaddingLeft() - getPaddingRight() - 4 * gap) / 5);
        int cw = MeasureSpec.makeMeasureSpec(tileW, MeasureSpec.EXACTLY);
        int ch = MeasureSpec.makeMeasureSpec(tileH, MeasureSpec.EXACTLY);
        for (int i = 0; i < getChildCount(); i++) getChildAt(i).measure(cw, ch);
        setMeasuredDimension(w, tileH + 2 * pad);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            getChildAt(i).layout(getPaddingLeft(), pad, getPaddingLeft() + tileW, pad + tileH);
        }
        positionAll(false, -1);
    }

    private float slotX(int pos) {
        return pos * (tileW + gap);
    }

    private int posOf(int unit) {
        for (int p = 0; p < 5; p++) if (state.order[p] == unit) return p;
        return 0;
    }

    /** Puts every tile (except skipUnit, which the finger is holding) into its slot. */
    private void positionAll(boolean animate, int skipUnit) {
        for (int pos = 0; pos < 5; pos++) {
            int unit = state.order[pos];
            if (unit == skipUnit) continue;
            TextView t = tiles[unit];
            if (animate) {
                t.animate().translationX(slotX(pos)).setDuration(170)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else {
                t.animate().cancel();
                t.setTranslationX(slotX(pos));
            }
        }
    }

    // ------------------------------------------------------------------ look

    private void restyleAll() {
        for (int unit = 0; unit < 5; unit++) style(unit);
    }

    private void style(int unit) {
        TextView t = tiles[unit];
        boolean on = state.on[unit];
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(16 * getResources().getDisplayMetrics().density);
        if (on) {
            g.setColor(accent);
        } else {
            float d = getResources().getDisplayMetrics().density;
            g.setColor(0xFF1C1C20);
            g.setStroke((int) (2 * d), 0xFF3F3F46, 6 * d, 4 * d);
        }
        t.setBackground(g);
        t.setTextColor(on ? 0xFFFFFFFF : 0xFF77777F);
    }

    // ------------------------------------------------------------------ touch

    private void attachTouch(final TextView tile, final int unit) {
        tile.setOnTouchListener(new OnTouchListener() {
            float downRawX, startTx;
            long downTime;
            boolean dragging;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = e.getRawX();
                        startTx = v.getTranslationX();
                        downTime = e.getEventTime();
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downRawX;
                        if (!dragging && Math.abs(dx) > slop) {
                            dragging = true;
                            getParent().requestDisallowInterceptTouchEvent(true);
                            beginDrag(tile);
                        }
                        if (dragging) drag(tile, unit, startTx + dx);
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                        if (dragging) endDrag(tile, unit);
                        else if (e.getEventTime() - downTime < 450) toggle(unit);
                        dragging = false;
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        if (dragging) endDrag(tile, unit);
                        dragging = false;
                        return true;
                }
                return false;
            }
        });
    }

    private void beginDrag(TextView tile) {
        tile.animate().cancel();
        tile.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        float d = getResources().getDisplayMetrics().density;
        tile.animate().scaleX(1.12f).scaleY(1.12f).translationZ(14 * d).setDuration(120).start();
    }

    private void drag(TextView tile, int unit, float x) {
        float max = slotX(4);
        x = Math.max(0f, Math.min(max, x));
        tile.setTranslationX(x);
        int target = Math.round(x / (tileW + gap));
        int cur = posOf(unit);
        if (target != cur) {
            if (target > cur) {
                for (int i = cur; i < target; i++) state.order[i] = state.order[i + 1];
            } else {
                for (int i = cur; i > target; i--) state.order[i] = state.order[i - 1];
            }
            state.order[target] = unit;
            tile.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            positionAll(true, unit);   // the others slide out of the way
        }
    }

    private void endDrag(TextView tile, int unit) {
        tile.animate().translationX(slotX(posOf(unit))).scaleX(1f).scaleY(1f).translationZ(0f)
                .setDuration(180).setInterpolator(new OvershootInterpolator(1.2f)).start();
        notifyChanged();
    }

    private void toggle(int unit) {
        TextView tile = tiles[unit];
        if (state.on[unit] && state.visibleCount() <= 1) {
            Toast.makeText(getContext(), "Keep at least one unit", Toast.LENGTH_SHORT).show();
            tile.animate().translationXBy(10f).setDuration(60).withEndAction(() ->
                    tile.animate().translationXBy(-20f).setDuration(80).withEndAction(() ->
                            tile.animate().translationXBy(10f).setDuration(60).start()).start()).start();
            return;
        }
        state.on[unit] = !state.on[unit];
        style(unit);
        tile.setScaleX(0.86f);
        tile.setScaleY(0.86f);
        tile.animate().scaleX(1f).scaleY(1f).setDuration(220)
                .setInterpolator(new OvershootInterpolator(2f)).start();
        notifyChanged();
    }

    private void notifyChanged() {
        if (listener != null) listener.onChanged(state.copy());
    }
}
