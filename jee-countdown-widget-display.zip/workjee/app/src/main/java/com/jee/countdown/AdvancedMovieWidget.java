package com.jee.countdown;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

/** JEE Advanced Style 2 (movie style). Independent of the Mains widgets. */
public class AdvancedMovieWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Updater.render(context);
        Updater.startLive(context);
        Updater.poke(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle newOptions) {
        Updater.renderCountdowns(context);
    }

    @Override
    public void onEnabled(Context context) {
        Updater.schedule(context);
    }

    @Override
    public void onDisabled(Context context) {
        Updater.cancelIfUnused(context);
    }
}
