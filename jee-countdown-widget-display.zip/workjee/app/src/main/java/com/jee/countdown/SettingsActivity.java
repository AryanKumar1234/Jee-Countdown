package com.jee.countdown;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/** "Widget display": choose which units the widgets show and in what order. */
public class SettingsActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ticking = false;
    private View card;
    private TextView cardTitle, cardNum, cardSub;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            refreshPreview();
            long delay = 1000L - (System.currentTimeMillis() % 1000L);
            h.postAtTime(this, SystemClock.uptimeMillis() + Math.max(1L, delay));
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);
        card = findViewById(R.id.s_card);
        cardTitle = findViewById(R.id.s_card_title);
        cardNum = findViewById(R.id.s_card_num);
        cardSub = findViewById(R.id.s_card_sub);
        TextView label = findViewById(R.id.s_label);
        TextView back = findViewById(R.id.s_back);
        Button reset = findViewById(R.id.s_reset);
        TileBoard board = findViewById(R.id.s_board);

        int accent = Updater.accentColor(this);
        label.setTextColor(accent);
        card.setBackgroundTintList(ColorStateList.valueOf(accent));
        board.setAccent(accent);
        board.setState(Updater.loadLayout(this));
        board.setListener(layout -> {
            Updater.saveLayout(this, layout);   // widgets redraw straight away
            refreshPreview();
        });

        back.setOnClickListener(v -> finish());
        reset.setOnClickListener(v -> board.reset());
        refreshPreview();
    }

    @Override
    protected void onResume() {
        super.onResume();
        ticking = true;
        h.post(tick);
    }

    @Override
    protected void onPause() {
        ticking = false;
        h.removeCallbacks(tick);
        super.onPause();
    }

    private void refreshPreview() {
        cardTitle.setText(Updater.title(this));
        cardNum.setText(Updater.previewNumText(this));
        cardSub.setText(Updater.subtitle(this));
    }
}
