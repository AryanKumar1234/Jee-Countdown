package com.jee.countdown;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.text.Layout;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;
import android.util.AttributeSet;
import android.widget.TextView;

/**
 * TextView that paints its text with a rainbow gradient spread across the text itself.
 * Any '*' is drawn solid red instead. A shader is used (not per-letter colours) so
 * Telugu / Kannada / Hindi letters keep joining correctly.
 */
public class RainbowTextView extends TextView {
    /** red, orange, yellow, green, blue, indigo, violet (bright, readable on black) */
    static final int[] RAINBOW = {
            0xFFFF1744, 0xFFFF9100, 0xFFFFEA00, 0xFF00E676,
            0xFF448AFF, 0xFF7C4DFF, 0xFFE040FB
    };
    static final int STAR_RED = 0xFFFF0000;

    private Shader shader;
    private float shaderX0 = Float.NaN, shaderX1 = Float.NaN;

    public RainbowTextView(Context c) { super(c); }
    public RainbowTextView(Context c, AttributeSet a) { super(c, a); }
    public RainbowTextView(Context c, AttributeSet a, int d) { super(c, a, d); }

    /** Marks every '*' in the text so it is drawn in solid red. */
    static CharSequence redStars(String text) {
        SpannableString s = new SpannableString(text);
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '*') s.setSpan(new RedStar(), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        return s;
    }

    private static final class RedStar extends CharacterStyle {
        @Override
        public void updateDrawState(TextPaint tp) {
            tp.setShader(null);
            tp.setColor(STAR_RED);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        Layout l = getLayout();
        if (l != null && l.getLineCount() > 0 && getText().length() > 0) {
            float x0 = Float.MAX_VALUE, x1 = 0f;
            for (int i = 0; i < l.getLineCount(); i++) {
                x0 = Math.min(x0, l.getLineLeft(i));
                x1 = Math.max(x1, l.getLineRight(i));
            }
            if (x1 - x0 < 1f) x1 = x0 + 1f;
            if (shader == null || x0 != shaderX0 || x1 != shaderX1) {
                shader = new LinearGradient(x0, 0, x1, 0, RAINBOW, null, Shader.TileMode.CLAMP);
                shaderX0 = x0;
                shaderX1 = x1;
            }
            getPaint().setShader(shader);
        } else {
            getPaint().setShader(null);
        }
        super.onDraw(canvas);
    }
}
