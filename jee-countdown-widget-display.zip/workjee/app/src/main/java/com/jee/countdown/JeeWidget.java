package com.jee.countdown;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;

public class JeeWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        Updater.render(ctx);
        Updater.startLive(ctx);
        Updater.poke(ctx);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int appWidgetId, Bundle newOptions) {
        // Rebuild RemoteViews after the launcher changes the widget's dimensions.
        Updater.renderCountdowns(ctx);
    }

    @Override
    public void onEnabled(Context ctx) {
        Updater.schedule(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        Updater.cancelIfUnused(ctx);
    }
}
