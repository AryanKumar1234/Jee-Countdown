package com.jee.countdown;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.widget.ImageView;
import android.widget.FrameLayout;
import android.widget.Button;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.SharedPreferences;
import java.util.Calendar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean ticking = false;
    private TextView title, sub, msg, label, plusBtn;
    private Button btnMains, btnAdvanced;
    private int lastAccent = 0;
    private TextView[] nums;
    private final Random rnd = new Random();
    private String[] names;
    private int lastName = -1;
    private Toast toast;
    private Bitmap fingerBmp;
    private static final int FINGERS_PER_TAP = 26;

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            bind();
            long delay = 1000L - (System.currentTimeMillis() % 1000L);
            h.postAtTime(this, android.os.SystemClock.uptimeMillis() + Math.max(1L, delay));
        }
    };

    private final Runnable hideMsg = () -> msg.setText("");

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        title = findViewById(R.id.a_title);
        sub = findViewById(R.id.a_sub);
        msg = findViewById(R.id.a_msg);
        label = findViewById(R.id.a_label);
        plusBtn = findViewById(R.id.a_plus);   // needed before the first applyAccent()
        nums = new TextView[]{
                findViewById(R.id.a_y), findViewById(R.id.a_d), findViewById(R.id.a_h),
                findViewById(R.id.a_m), findViewById(R.id.a_s)};

        Button mains = findViewById(R.id.a_mains);
        Button advanced = findViewById(R.id.a_advanced);
        btnMains = mains;
        btnAdvanced = advanced;
        mains.setOnClickListener(v -> {
            Updater.selectMains(this);
            updateExamButtons(mains, advanced);
            bind();
        });
        // A normal tap selects the published JEE Advanced 2027 date.
        // Long-press remains available for a custom date.
        advanced.setOnClickListener(v -> {
            Updater.selectAdvancedDefault(this);
            updateExamButtons(mains, advanced);
            bind();
        });
        advanced.setOnLongClickListener(v -> {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(Updater.defaultAdvancedEpochMillis());
            SharedPreferences sp = getSharedPreferences("jee", MODE_PRIVATE);
            long saved = sp.getLong("advanced_picker_epoch", Updater.defaultAdvancedEpochMillis());
            c.setTimeInMillis(saved);
            new DatePickerDialog(this, (view, year, month, day) -> {
                Calendar chosen = Calendar.getInstance();
                chosen.set(year, month, day, 9, 0, 0);
                chosen.set(Calendar.MILLISECOND, 0);
                sp.edit().putLong("advanced_picker_epoch", chosen.getTimeInMillis()).apply();
                Updater.selectAdvanced(this, chosen.getTimeInMillis());
                updateExamButtons(mains, advanced);
                bind();
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
            return true;
        });
        updateExamButtons(mains, advanced);

        TextView plus = findViewById(R.id.a_plus);
        plusBtn = plus;
        findViewById(R.id.a_gear).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        names = loadNames();
        plus.setOnClickListener(v -> {
            plus.animate().rotationBy(90f).setDuration(200).start();
            String name = nextName();
            msg.setText(RainbowTextView.redStars(name));   // rainbow gradient, '*' in red
            if (toast != null) toast.cancel();
            toast = Toast.makeText(this, name, Toast.LENGTH_SHORT);
            toast.show();
            h.removeCallbacks(hideMsg);
            h.postDelayed(hideMsg, 3000);
            spawnFingers();
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Updater.schedule(this);
        Updater.startLive(this);   // keeps widget seconds running too
        Updater.pokeForce(this);   // fetch the latest date and news
        ticking = true;
        h.post(tick);
    }

    @Override
    protected void onPause() {
        ticking = false;
        h.removeCallbacks(tick);
        super.onPause();
    }

    // ------------------------------------------------------------ names + finger effect

    /** Reads res/raw/padhle_names.txt (one name per line). */
    private String[] loadNames() {
        ArrayList<String> out = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(
                getResources().openRawResource(R.raw.padhle_names), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) out.add(line);
            }
        } catch (IOException ignored) {
        }
        if (out.isEmpty()) out.add("Padhle B**K");
        return out.toArray(new String[0]);
    }

    /** A random name, never the same one twice in a row. */
    private String nextName() {
        int i;
        do {
            i = rnd.nextInt(names.length);
        } while (names.length > 1 && i == lastName);
        lastName = i;
        return names[i];
    }

    /** The middle-finger emoji drawn once into a bitmap, so it can be tinted any colour. */
    private Bitmap fingerBitmap() {
        if (fingerBmp == null) {
            int size = (int) (96 * getResources().getDisplayMetrics().density);
            Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setTextSize(size * 0.8f);
            p.setTextAlign(Paint.Align.CENTER);
            Paint.FontMetrics fm = p.getFontMetrics();
            new Canvas(b).drawText("\uD83D\uDD95", size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p);
            fingerBmp = b;
        }
        return fingerBmp;
    }

    /** Recolours the emoji to one solid rainbow colour while keeping its shading and outline. */
    private static ColorMatrixColorFilter tint(int color) {
        float r = Color.red(color) / 255f, g = Color.green(color) / 255f, bl = Color.blue(color) / 255f;
        float lr = 0.299f * 1.25f, lg = 0.587f * 1.25f, lb = 0.114f * 1.25f; // luminance, a bit boosted
        return new ColorMatrixColorFilter(new float[]{
                r * lr,  r * lg,  r * lb,  0, 0,
                g * lr,  g * lg,  g * lb,  0, 0,
                bl * lr, bl * lg, bl * lb, 0, 0,
                0, 0, 0, 1, 0});
    }

    /** Pops middle fingers all over the screen, each in a random rainbow colour. */
    private void spawnFingers() {
        final FrameLayout fx = findViewById(R.id.a_fx);
        final int w = fx.getWidth(), hgt = fx.getHeight();
        if (w <= 0 || hgt <= 0 || fx.getChildCount() > 150) return;
        final float d = getResources().getDisplayMetrics().density;
        final Bitmap bmp = fingerBitmap();
        for (int i = 0; i < FINGERS_PER_TAP; i++) {
            final int size = (int) ((44 + rnd.nextInt(60)) * d);
            final int x = rnd.nextInt(Math.max(1, w - size));
            final int y = rnd.nextInt(Math.max(1, hgt - size));
            final int color = RainbowTextView.RAINBOW[rnd.nextInt(RainbowTextView.RAINBOW.length)];
            final float tilt = (rnd.nextFloat() - 0.5f) * 70f;
            h.postDelayed(() -> {
                final ImageView iv = new ImageView(this);
                iv.setImageBitmap(bmp);
                iv.setColorFilter(tint(color));
                iv.setAlpha(0f);
                iv.setScaleX(0.2f);
                iv.setScaleY(0.2f);
                iv.setRotation(tilt);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(size, size);
                lp.leftMargin = x;
                lp.topMargin = y;
                fx.addView(iv, lp);
                iv.animate().alpha(1f).scaleX(1f).scaleY(1f)
                        .setDuration(220).setStartDelay(0)
                        .setInterpolator(new OvershootInterpolator())
                        .withEndAction(() -> iv.animate().alpha(0f)
                                .translationYBy(-70 * d)
                                .setStartDelay(550).setDuration(650)
                                .setInterpolator(new AccelerateInterpolator())
                                .withEndAction(() -> fx.removeView(iv))
                                .start())
                        .start();
            }, rnd.nextInt(700));
        }
    }

    private void updateExamButtons(Button mains, Button advanced) {
        boolean isAdvanced = Updater.isAdvanced(this);
        mains.setAlpha(isAdvanced ? 0.55f : 1f);
        advanced.setAlpha(isAdvanced ? 1f : 0.55f);
        lastAccent = 0;   // force the accent colour to be re-applied for the new selection
        applyAccent();
    }

    /** Colours the screen with the selected exam's phase colour, like the Style 1 widget. */
    private void applyAccent() {
        int accent = Updater.accentColor(this);
        if (accent == lastAccent || btnMains == null) return;
        lastAccent = accent;
        boolean isAdvanced = Updater.isAdvanced(this);
        ColorStateList on = ColorStateList.valueOf(accent);
        ColorStateList off = ColorStateList.valueOf(0xFF343438);
        btnMains.setBackgroundTintList(isAdvanced ? off : on);
        btnAdvanced.setBackgroundTintList(isAdvanced ? on : off);
        label.setTextColor(accent);
        plusBtn.setTextColor(accent);
        if (plusBtn.getBackground() != null) plusBtn.getBackground().mutate().setTint(accent);
    }

    private void bind() {
        applyAccent();
        final int accent = lastAccent != 0 ? lastAccent : 0xFFE10600;
        long[] v = Updater.parts(this);
        boolean leadingZero = true;
        for (int i = 0; i < 5; i++) {
            if (v[i] != 0) leadingZero = false;
            nums[i].setText(v[i] < 10 ? "0" + v[i] : String.valueOf(v[i]));
            nums[i].setTextColor(leadingZero && i < 4 ? accent : 0xFFFFFFFF);
        }
        title.setText(Updater.title(this));
        sub.setText(Updater.subtitle(this));
    }
}
