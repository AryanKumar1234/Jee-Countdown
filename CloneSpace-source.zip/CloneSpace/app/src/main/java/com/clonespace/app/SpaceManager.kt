package com.clonespace.app

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.os.UserHandle
import android.os.UserManager
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class SpaceManager(private val context: Context) {

    private val userManager = context.getSystemService(Context.USER_SERVICE) as UserManager
    private val launcherApps = context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private val pm = context.packageManager

    fun isRunningInsideParallelSpace(): Boolean {
        return dpm.isProfileOwnerApp(context.packageName)
    }

    fun getParallelProfileHandle(): UserHandle? {
        val currentUser = Process.myUserHandle()
        return userManager.userProfiles.firstOrNull { it != currentUser }
    }

    fun hasParallelSpace(): Boolean {
        return isRunningInsideParallelSpace() || getParallelProfileHandle() != null
    }

    fun isSpacePaused(): Boolean {
        val handle = getParallelProfileHandle() ?: return false
        return userManager.isQuietModeEnabled(handle)
    }

    fun setSpacePaused(pause: Boolean): Boolean {
        val handle = getParallelProfileHandle() ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return userManager.requestQuietModeEnabled(pause, handle)
        }
        return false
    }

    fun toggleSpacePause(): Boolean {
        val handle = getParallelProfileHandle() ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val shouldPause = !userManager.isQuietModeEnabled(handle)
            return userManager.requestQuietModeEnabled(shouldPause, handle)
        }
        return false
    }

    fun createProvisioningIntent(): Intent {
        return Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE).apply {
            putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                SpaceAdminReceiver.getComponentName(context)
            )
            putExtra(
                DevicePolicyManager.EXTRA_PROVISIONING_SKIP_ENCRYPTION,
                true
            )
        }
    }

    suspend fun loadClonedApps(): List<AppItem> = withContext(Dispatchers.IO) {
        val targetHandle = if (isRunningInsideParallelSpace()) {
            Process.myUserHandle()
        } else {
            getParallelProfileHandle()
        } ?: return@withContext emptyList()

        val activities = try {
            launcherApps.getActivityList(null, targetHandle)
        } catch (_: Exception) {
            emptyList()
        }

        activities
            .filter { it.applicationInfo.packageName != context.packageName }
            .distinctBy { it.applicationInfo.packageName }
            .map { info ->
                AppItem(
                    packageName = info.applicationInfo.packageName,
                    label = info.label?.toString() ?: info.applicationInfo.packageName,
                    icon = info.getBadgedIcon(0),
                    componentName = info.componentName,
                    userHandle = targetHandle,
                    isCloned = true
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    suspend fun loadMainProfileApps(clonedPackages: Set<String>): List<AppItem> =
        withContext(Dispatchers.IO) {
            val installed = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            installed
                .filter { appInfo ->
                    appInfo.packageName != context.packageName &&
                        pm.getLaunchIntentForPackage(appInfo.packageName) != null &&
                        (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                }
                .map { appInfo ->
                    AppItem(
                        packageName = appInfo.packageName,
                        label = pm.getApplicationLabel(appInfo).toString(),
                        icon = pm.getApplicationIcon(appInfo),
                        isCloned = clonedPackages.contains(appInfo.packageName)
                    )
                }
                .sortedBy { it.label.lowercase() }
        }

    fun launchClonedApp(item: AppItem): Boolean {
        val component = item.componentName ?: return false
        val handle = item.userHandle ?: return false
        return try {
            launcherApps.startMainActivity(component, handle, null, null)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openClonedAppDetails(item: AppItem) {
        val component = item.componentName ?: return
        val handle = item.userHandle ?: return
        try {
            launcherApps.startAppDetailsActivity(component, handle, null, null)
        } catch (_: Exception) {
            // Ignored if profile is paused
        }
    }

    suspend fun prepareCloneInstallIntent(packageName: String): Intent? =
        withContext(Dispatchers.IO) {
            try {
                val appInfo = pm.getApplicationInfo(packageName, 0)
                val sourceApk = File(appInfo.publicSourceDir)
                if (!sourceApk.exists()) return@withContext null

                val cacheDir = File(context.cacheDir, "cloned_apks").apply { mkdirs() }
                cacheDir.listFiles()?.forEach { it.delete() }

                val stagedApk = File(cacheDir, "${packageName}.apk")
                sourceApk.copyTo(stagedApk, overwrite = true)

                val apkUri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    stagedApk
                )

                Intent(SpaceAdminReceiver.ACTION_INSTALL_CLONE).apply {
                    setDataAndType(apkUri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    putExtra(Intent.EXTRA_STREAM, apkUri)
                }
            } catch (_: Exception) {
                null
            }
        }
}
