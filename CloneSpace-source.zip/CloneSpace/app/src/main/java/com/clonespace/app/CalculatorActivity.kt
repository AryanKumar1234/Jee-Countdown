package com.clonespace.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.clonespace.app.databinding.ActivityCalculatorBinding
import java.text.DecimalFormat

/**
 * Stealth front-end disguised as a standard Calculator.
 * Entering the secret PIN (default: 1234) and pressing '=' unlocks the hidden CloneSpace vault.
 */
class CalculatorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCalculatorBinding

    private var currentInput: String = ""
    private var firstOperand: Double? = null
    private var pendingOperator: String? = null
    private var rawPinBuffer: String = ""
    private val formatter = DecimalFormat("#.########")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalculatorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        updateDisplay()
    }

    private fun setupButtons() {
        val digitButtons = mapOf(
            binding.btn0 to "0",
            binding.btn1 to "1",
            binding.btn2 to "2",
            binding.btn3 to "3",
            binding.btn4 to "4",
            binding.btn5 to "5",
            binding.btn6 to "6",
            binding.btn7 to "7",
            binding.btn8 to "8",
            binding.btn9 to "9"
        )

        digitButtons.forEach { (button, digit) ->
            button.setOnClickListener {
                currentInput += digit
                rawPinBuffer += digit
                updateDisplay()
            }
        }

        binding.btnDot.setOnClickListener {
            if (!currentInput.contains(".")) {
                currentInput = if (currentInput.isEmpty()) "0." else "$currentInput."
                rawPinBuffer = ""
                updateDisplay()
            }
        }

        binding.btnClear.setOnClickListener {
            clearAll()
        }

        binding.btnBackspace.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                currentInput = currentInput.dropLast(1)
            }
            if (rawPinBuffer.isNotEmpty()) {
                rawPinBuffer = rawPinBuffer.dropLast(1)
            }
            updateDisplay()
        }

        binding.btnAdd.setOnClickListener { selectOperator("+") }
        binding.btnSub.setOnClickListener { selectOperator("-") }
        binding.btnMul.setOnClickListener { selectOperator("×") }
        binding.btnDiv.setOnClickListener { selectOperator("÷") }

        binding.btnEquals.setOnClickListener {
            val secretPin = VaultPrefs.getPin(this)
            if (pendingOperator == null && rawPinBuffer == secretPin) {
                clearAll()
                openHiddenVault()
                return@setOnClickListener
            }
            evaluateExpression()
        }
    }

    private fun selectOperator(op: String) {
        rawPinBuffer = ""
        val value = currentInput.toDoubleOrNull()
        if (value != null) {
            if (firstOperand == null) {
                firstOperand = value
            } else if (pendingOperator != null) {
                firstOperand = compute(firstOperand!!, value, pendingOperator!!)
            }
            currentInput = ""
        }
        if (firstOperand != null) {
            pendingOperator = op
        }
        updateDisplay()
    }

    private fun evaluateExpression() {
        rawPinBuffer = ""
        val left = firstOperand ?: return
        val right = currentInput.toDoubleOrNull() ?: return
        val op = pendingOperator ?: return

        val result = compute(left, right, op)
        if (result.isNaN() || result.isInfinite()) {
            clearAll()
            binding.displayText.text = getString(R.string.calc_error)
            return
        }
        currentInput = formatter.format(result)
        firstOperand = null
        pendingOperator = null
        updateDisplay()
    }

    private fun compute(a: Double, b: Double, op: String): Double {
        return when (op) {
            "+" -> a + b
            "-" -> a - b
            "×" -> a * b
            "÷" -> if (b == 0.0) Double.NaN else a / b
            else -> b
        }
    }

    private fun clearAll() {
        currentInput = ""
        firstOperand = null
        pendingOperator = null
        rawPinBuffer = ""
        updateDisplay()
    }

    private fun updateDisplay() {
        val expression = buildString {
            if (firstOperand != null && pendingOperator != null) {
                append(formatter.format(firstOperand))
                append(" ")
                append(pendingOperator)
                append(" ")
            }
        }
        binding.expressionText.text = expression
        binding.displayText.text = currentInput.ifEmpty { "0" }
    }

    private fun openHiddenVault() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }
        startActivity(intent)
    }
}
