package com.clonespace.app

import android.content.Context

object VaultPrefs {
    private const val PREF_NAME = "calc_vault_prefs"
    private const val KEY_PIN = "secret_pin"
    const val DEFAULT_PIN = "1234"

    fun getPin(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_PIN, DEFAULT_PIN) ?: DEFAULT_PIN
    }

    fun setPin(context: Context, newPin: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PIN, newPin).apply()
    }
}
