package com.clonespace.app

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class CloneInstallerActivity : AppCompatActivity() {

    private var pendingLocalUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val incomingUri: Uri? = intent?.data ?: if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(Intent.EXTRA_STREAM)
        }

        if (incomingUri == null) {
            Toast.makeText(this, R.string.clone_failed_toast, Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        lifecycleScope.launch {
            val localUri = copyUriToLocalCache(incomingUri)
            if (localUri == null) {
                Toast.makeText(this@CloneInstallerActivity, R.string.clone_failed_toast, Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            pendingLocalUri = localUri
            triggerPackageInstall(localUri)
        }
    }

    override fun onResume() {
        super.onResume()
        val uri = pendingLocalUri ?: return
        if (packageManager.canRequestPackageInstalls()) {
            pendingLocalUri = null
            launchSystemInstaller(uri)
            finish()
        }
    }

    private fun triggerPackageInstall(localUri: Uri) {
        if (!packageManager.canRequestPackageInstalls()) {
            Toast.makeText(this, R.string.allow_install_permission_toast, Toast.LENGTH_LONG).show()
            val settingsIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:$packageName")
            )
            startActivity(settingsIntent)
            return
        }
        pendingLocalUri = null
        launchSystemInstaller(localUri)
        finish()
    }

    private fun launchSystemInstaller(apkUri: Uri) {
        val installIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(installIntent)
    }

    private suspend fun copyUriToLocalCache(sourceUri: Uri): Uri? = withContext(Dispatchers.IO) {
        try {
            val dir = File(cacheDir, "cloned_apks").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val outFile = File(dir, "clone_install_${System.currentTimeMillis()}.apk")
            contentResolver.openInputStream(sourceUri)?.use { input ->
                outFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return@withContext null

            FileProvider.getUriForFile(
                this@CloneInstallerActivity,
                "$packageName.fileprovider",
                outFile
            )
        } catch (_: Exception) {
            null
        }
    }
}
