package com.clonespace.app

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.clonespace.app.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var spaceManager: SpaceManager

    private lateinit var clonedAdapter: AppListAdapter
    private lateinit var pickerAdapter: AppListAdapter

    private var allClonedApps: List<AppItem> = emptyList()
    private var allMainApps: List<AppItem> = emptyList()
    private var activeTab: Int = 0
    private var searchQuery: String = ""

    private val provisionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshDashboard()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        spaceManager = SpaceManager(this)
        setupRecyclerViews()
        setupControls()
    }

    override fun onResume() {
        super.onResume()
        refreshDashboard()
    }

    private fun setupRecyclerViews() {
        clonedAdapter = AppListAdapter(
            mode = AppListAdapter.Mode.CLONED_SPACE,
            onPrimaryClick = { item ->
                if (!spaceManager.launchClonedApp(item)) {
                    Toast.makeText(this, R.string.launch_failed_toast, Toast.LENGTH_SHORT).show()
                }
            },
            onSecondaryClick = { item ->
                spaceManager.openClonedAppDetails(item)
            }
        )

        pickerAdapter = AppListAdapter(
            mode = AppListAdapter.Mode.CLONE_PICKER,
            onPrimaryClick = { item -> cloneAppIntoSpace(item) },
            onSecondaryClick = {}
        )

        binding.appsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.appsRecyclerView.adapter = clonedAdapter
    }

    private fun setupControls() {
        binding.changePinButton.setOnClickListener {
            showChangePinDialog()
        }

        binding.lockHideButton.setOnClickListener {
            if (spaceManager.hasParallelSpace() && !spaceManager.isSpacePaused()) {
                spaceManager.setSpacePaused(true)
            }
            Toast.makeText(this, R.string.vault_locked_toast, Toast.LENGTH_SHORT).show()
            finishAndRemoveTask()
        }

        binding.setupSpaceButton.setOnClickListener {
            try {
                provisionLauncher.launch(spaceManager.createProvisioningIntent())
            } catch (_: Exception) {
                Toast.makeText(this, R.string.provision_unsupported_toast, Toast.LENGTH_LONG).show()
            }
        }

        binding.pauseSpaceButton.setOnClickListener {
            spaceManager.toggleSpacePause()
            binding.root.postDelayed({ refreshDashboard() }, 400)
        }

        binding.swipeRefresh.setOnRefreshListener {
            refreshDashboard()
        }

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                activeTab = tab.position
                binding.appsRecyclerView.adapter = if (activeTab == 0) clonedAdapter else pickerAdapter
                applySearchFilter()
            }

            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })

        binding.searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                searchQuery = s?.toString()?.trim().orEmpty()
                applySearchFilter()
            }

            override fun afterTextChanged(s: Editable?) = Unit
        })
    }

    private fun showChangePinDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = getString(R.string.change_pin_hint)
            setText(VaultPrefs.getPin(this@MainActivity))
            setPadding(48, 32, 48, 24)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.change_pin_title)
            .setMessage(R.string.change_pin_message)
            .setView(input)
            .setPositiveButton(R.string.action_save) { _, _ ->
                val pin = input.text.toString().trim()
                if (pin.length in 4..8 && pin.all { it.isDigit() }) {
                    VaultPrefs.setPin(this, pin)
                    Toast.makeText(this, getString(R.string.pin_updated_toast, pin), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, R.string.pin_invalid_toast, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun refreshDashboard() {
        val hasSpace = spaceManager.hasParallelSpace()
        binding.setupCard.visibility = if (hasSpace) View.GONE else View.VISIBLE
        binding.workspaceContainer.visibility = if (hasSpace) View.VISIBLE else View.GONE

        if (!hasSpace) {
            binding.swipeRefresh.isRefreshing = false
            return
        }

        val isPaused = spaceManager.isSpacePaused()
        binding.spaceStatusText.setText(
            if (isPaused) R.string.space_status_paused else R.string.space_status_active
        )
        binding.pauseSpaceButton.setText(
            if (isPaused) R.string.action_resume_space else R.string.action_pause_space
        )

        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            allClonedApps = spaceManager.loadClonedApps()
            val clonedSet = allClonedApps.map { it.packageName }.toSet()
            allMainApps = spaceManager.loadMainProfileApps(clonedSet)
            applySearchFilter()
            binding.swipeRefresh.isRefreshing = false
        }
    }

    private fun applySearchFilter() {
        val q = searchQuery.lowercase()
        if (activeTab == 0) {
            val filtered = if (q.isEmpty()) allClonedApps else {
                allClonedApps.filter {
                    it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
                }
            }
            clonedAdapter.submitList(filtered)
            binding.emptyStateText.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            binding.emptyStateText.setText(R.string.empty_cloned_apps)
        } else {
            val filtered = if (q.isEmpty()) allMainApps else {
                allMainApps.filter {
                    it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
                }
            }
            pickerAdapter.submitList(filtered)
            binding.emptyStateText.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
            binding.emptyStateText.setText(R.string.empty_main_apps)
        }
    }

    private fun cloneAppIntoSpace(item: AppItem) {
        if (spaceManager.isSpacePaused()) {
            Toast.makeText(this, R.string.resume_before_clone_toast, Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(
            this,
            getString(R.string.cloning_app_toast, item.label),
            Toast.LENGTH_SHORT
        ).show()

        lifecycleScope.launch {
            val installIntent = spaceManager.prepareCloneInstallIntent(item.packageName)
            if (installIntent == null) {
                Toast.makeText(this@MainActivity, R.string.clone_failed_toast, Toast.LENGTH_SHORT).show()
                return@launch
            }
            try {
                startActivity(Intent.createChooser(installIntent, getString(R.string.choose_parallel_space_installer)))
            } catch (_: Exception) {
                Toast.makeText(this@MainActivity, R.string.clone_failed_toast, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
