package com.clonespace.app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.widget.Toast

class SpaceAdminReceiver : DeviceAdminReceiver() {

    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = getComponentName(context)

        dpm.setProfileName(admin, context.getString(R.string.parallel_profile_name))
        configureCrossProfileFilters(dpm, admin)
        dpm.setProfileEnabled(admin)

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
            )
        }
        context.startActivity(launchIntent)
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admin = getComponentName(context)
        if (dpm.isProfileOwnerApp(context.packageName)) {
            configureCrossProfileFilters(dpm, admin)
            Toast.makeText(context, R.string.space_ready_toast, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        const val ACTION_INSTALL_CLONE = "com.clonespace.app.ACTION_INSTALL_CLONE"

        fun getComponentName(context: Context): ComponentName {
            return ComponentName(context.applicationContext, SpaceAdminReceiver::class.java)
        }

        fun configureCrossProfileFilters(dpm: DevicePolicyManager, admin: ComponentName) {
            val installFilter = IntentFilter(ACTION_INSTALL_CLONE).apply {
                addCategory(Intent.CATEGORY_DEFAULT)
                addDataType("application/vnd.android.package-archive")
            }
            dpm.addCrossProfileIntentFilter(
                admin,
                installFilter,
                DevicePolicyManager.FLAG_MANAGED_CAN_ACCESS_PARENT or
                    DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED
            )
        }
    }
}
