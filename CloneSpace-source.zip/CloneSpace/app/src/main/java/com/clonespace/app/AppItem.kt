package com.clonespace.app

import android.content.ComponentName
import android.graphics.drawable.Drawable
import android.os.UserHandle

data class AppItem(
    val packageName: String,
    val label: String,
    val icon: Drawable,
    val componentName: ComponentName? = null,
    val userHandle: UserHandle? = null,
    val isCloned: Boolean = false
)
