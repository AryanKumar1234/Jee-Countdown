package com.clonespace.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.clonespace.app.databinding.ItemAppRowBinding

class AppListAdapter(
    private val mode: Mode,
    private val onPrimaryClick: (AppItem) -> Unit,
    private val onSecondaryClick: (AppItem) -> Unit
) : ListAdapter<AppItem, AppListAdapter.AppViewHolder>(DiffCallback) {

    enum class Mode { CLONED_SPACE, CLONE_PICKER }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AppViewHolder {
        val binding = ItemAppRowBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return AppViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AppViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class AppViewHolder(
        private val binding: ItemAppRowBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: AppItem) {
            binding.appIcon.setImageDrawable(item.icon)
            binding.appName.text = item.label
            binding.appPackage.text = item.packageName

            if (mode == Mode.CLONED_SPACE) {
                binding.primaryActionButton.setText(R.string.action_open)
                binding.primaryActionButton.isEnabled = true
                binding.secondaryActionButton.visibility = View.VISIBLE
                binding.secondaryActionButton.setOnClickListener { onSecondaryClick(item) }
            } else {
                binding.secondaryActionButton.visibility = View.GONE
                if (item.isCloned) {
                    binding.primaryActionButton.setText(R.string.action_cloned)
                    binding.primaryActionButton.isEnabled = false
                } else {
                    binding.primaryActionButton.setText(R.string.action_clone)
                    binding.primaryActionButton.isEnabled = true
                }
            }

            binding.primaryActionButton.setOnClickListener { onPrimaryClick(item) }
            binding.root.setOnClickListener {
                if (mode == Mode.CLONED_SPACE || !item.isCloned) {
                    onPrimaryClick(item)
                }
            }
        }
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<AppItem>() {
            override fun areItemsTheSame(oldItem: AppItem, newItem: AppItem): Boolean {
                return oldItem.packageName == newItem.packageName
            }

            override fun areContentsTheSame(oldItem: AppItem, newItem: AppItem): Boolean {
                return oldItem.packageName == newItem.packageName &&
                    oldItem.label == newItem.label &&
                    oldItem.isCloned == newItem.isCloned
            }
        }
    }
}
