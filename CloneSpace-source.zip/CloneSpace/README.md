# CloneSpace — Hidden Calculator Vault & Parallel App Cloner

CloneSpace disguises itself in your Android app drawer as a fully working **Calculator** app.

## How Stealth Mode Works

- **Calculator Disguise**: Appears as **Calculator** with a calculator icon on your home screen.
- **Secret PIN Unlock**: Type your PIN (default: `1234`) and press `=` to open your hidden Parallel Space vault. Tap **PIN** inside the vault to change it anytime.
- **Hidden from Recent Apps**: The vault dashboard uses `excludeFromRecents="true"` so it never appears in the Android app switcher.
- **One-Tap Lock & Hide**: Tapping **Lock & Hide** pauses the isolated Work Profile (silencing notifications and pausing cloned apps) and immediately removes the vault from memory.

## GitHub Build & Release

1. Upload `CloneSpace-source.zip` to the root of your GitHub repository.
2. Place `build.yml` at `.github/workflows/build.yml`.
3. Push to `main` or trigger **Run workflow** in GitHub Actions to auto-extract, compile, sign, and publish the APK under **Releases**.
